package jouer;

public class JeuFermeException extends Exception {

}
