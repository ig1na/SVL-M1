package jouer;

public interface De {
	public int lancer();
}
