package jouer;

public class DebitImpossibleException extends Exception {

}
