
public class SoldeInsuffisantException extends Exception {

}
